package com.hussein.startup

 class  UserContact{
    var name:String?=null
     var phoneNumber:String?=null
     constructor(name:String,phoneNumber:String){
         this.name=name
         this.phoneNumber=phoneNumber
     }
 }