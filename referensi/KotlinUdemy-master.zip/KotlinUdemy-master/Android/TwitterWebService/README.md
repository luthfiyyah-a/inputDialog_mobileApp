##Twitter AAP.
###This app is social media app that allows people to share their photos,status, and follow other people..
####The complete tutorial how to build it is on [UDEMY Android 7](https://www.udemy.com/android-tutorial-for-beginners/?instructorPreviewMode=guest)



![main](http://attach.alruabye.net/androidTutorialForBeginners/tweeterapp/login.png)


![main](http://attach.alruabye.net/androidTutorialForBeginners/tweeterapp/tweet1.png)

![main](http://attach.alruabye.net/androidTutorialForBeginners/tweeterapp/tweet2.png)

