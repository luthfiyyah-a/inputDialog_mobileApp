
fun main(){

println("Welcome to kotlin")
println(" Hussein")
print("How is your day")

}