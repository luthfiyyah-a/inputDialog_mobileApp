


fun main(){

    print("Enter your age: ")
    val age = readLine()!!.toInt()

    if(age >=18){
        println("You could apply for the job")
    }else{
        println("You can not apply for the job")
    }

    print("END APP")

}