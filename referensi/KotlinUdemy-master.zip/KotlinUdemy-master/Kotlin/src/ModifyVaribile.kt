

fun main(){

    var count =1
    println("Count: $count")

    count += 1
    println("Count: $count")

    count += 3
    println("Count: $count")

    count -= 2
    println("Count: $count")

}