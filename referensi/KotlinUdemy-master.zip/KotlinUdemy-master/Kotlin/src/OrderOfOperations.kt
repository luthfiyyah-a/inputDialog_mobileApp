

fun main(){

    val number1= 3
    val number2=10
    val number3= 5
    val temp = number1+number2*number3

    print(temp )

}